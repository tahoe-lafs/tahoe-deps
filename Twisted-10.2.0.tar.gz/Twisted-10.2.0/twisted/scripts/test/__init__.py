# Copyright (c) 2008 Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Test package for L{twisted.scripts}.
"""
