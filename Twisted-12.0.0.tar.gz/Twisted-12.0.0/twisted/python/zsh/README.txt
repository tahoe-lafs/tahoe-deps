THIS DIRECTORY AND ALL FILES INCLUDED ARE DEPRECATED.

These are the old zsh completion functions for Twisted commands... they used
to contain full completion functions, but now they've simply been replaced
by the current "stub" code that delegates completion control to Twisted.

This directory and included files need to remain for several years in order
to provide backwards-compatibility with an old version of the Twisted
stub function that was shipped with Zsh.
