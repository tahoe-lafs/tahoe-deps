
/**
 * Currently it is undocumented and difficult to figure out how to create JS
 * modules and dependencies quickly and clearly for testing purposes.  This
 * package is a workaround for that, which provides some static fixtures for a
 * few Python tests to rely on.  At some point we should clean up and document
 * the JS modules API and LivePage's usage of it, and remove this package.
 */
