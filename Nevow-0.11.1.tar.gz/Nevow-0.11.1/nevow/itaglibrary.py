from zope.interface import Interface

class ICalendarOptions(Interface):
    pass
