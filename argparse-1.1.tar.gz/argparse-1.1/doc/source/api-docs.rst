API documentation
-----------------

.. toctree::
    :maxdepth: 2

    ArgumentParser
    add_argument
    parse_args
    other-methods
    other-utilities