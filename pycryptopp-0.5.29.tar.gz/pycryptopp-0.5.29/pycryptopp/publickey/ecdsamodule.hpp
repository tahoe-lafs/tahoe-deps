#ifndef __INCL_ECDSAMODULE_HPP
#define __INCL_ECDSAMODULE_HPP

void
init_ecdsa(PyObject* module);

#endif /* #ifndef __INCL_ECDSAMODULE_HPP */
