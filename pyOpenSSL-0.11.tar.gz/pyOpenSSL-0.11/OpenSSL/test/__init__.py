# Copyright (C) Jean-Paul Calderone 2008, All rights reserved

"""
Package containing unit tests for L{OpenSSL}.
"""
