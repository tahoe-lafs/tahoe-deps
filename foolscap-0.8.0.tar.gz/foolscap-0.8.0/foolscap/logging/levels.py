
import logging
NOISY = logging.DEBUG # 10
OPERATIONAL = logging.INFO # 20
UNUSUAL = logging.INFO+3
INFREQUENT = logging.INFO+5
CURIOUS = logging.INFO+8
WEIRD = logging.WARNING # 30
SCARY = logging.WARNING+5
BAD = logging.ERROR # 40
