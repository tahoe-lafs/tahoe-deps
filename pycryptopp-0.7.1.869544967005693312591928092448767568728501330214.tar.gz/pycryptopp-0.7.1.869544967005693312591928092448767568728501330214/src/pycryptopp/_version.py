
# This is the version of this tree, as created by pycryptopp's setup.py from the
# git information: the main version number is taken from the most recent
# release tag. If some patches have been added since the last release, this
# will have a -NN "build number" suffix, followed by -gXXX "revid" suffix.

__pkgname__ = "pycryptopp"
__version__ = "0.7.1.869544967005693312591928092448767568728501330214"
