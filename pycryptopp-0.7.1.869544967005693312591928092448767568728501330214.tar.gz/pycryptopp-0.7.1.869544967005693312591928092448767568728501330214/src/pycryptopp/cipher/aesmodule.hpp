#ifndef __INCL_AESMODULE_HPP
#define __INCL_AESMODULE_HPP

extern void
init_aes(PyObject* module);

#endif /* #ifndef __INCL_AESMODULE_HPP */
