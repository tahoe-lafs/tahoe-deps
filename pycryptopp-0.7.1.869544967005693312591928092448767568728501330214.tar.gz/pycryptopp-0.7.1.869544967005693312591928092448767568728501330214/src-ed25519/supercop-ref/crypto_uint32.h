#ifndef crypto_uint32_h
#define crypto_uint32_h

typedef unsigned int crypto_uint32;

#endif
