"""
Package for Nevow plugins.
"""

import os, sys
__path__ = [os.path.abspath(os.path.join(x, 'nevow', 'plugins')) for x in sys.path]

__all__ = []                    # nothing to see here, move along, move along
