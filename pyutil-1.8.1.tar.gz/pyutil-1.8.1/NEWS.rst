﻿2010-09-02

 version_class:

    * Copy in Tarek Ziadé's verlib to use as the comparison between Version instances.
    * Reject 'rc' after the version number (you have to use 'c' instead).
    * Add tests.
