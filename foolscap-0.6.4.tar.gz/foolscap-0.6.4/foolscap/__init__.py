"""Foolscap"""

from _version import verstr as __version__

# hush pyflakes
_unused = __version__; del _unused
