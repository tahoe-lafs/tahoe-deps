#ifndef __INCL_XSALSA20MODULE_HPP
#define __INCL_XSALSA20MODULE_HPP

extern void init_xsalsa20(PyObject* module);

#endif; /*#ifndef __INCL_XSALSA20MODULE_HPP*/
