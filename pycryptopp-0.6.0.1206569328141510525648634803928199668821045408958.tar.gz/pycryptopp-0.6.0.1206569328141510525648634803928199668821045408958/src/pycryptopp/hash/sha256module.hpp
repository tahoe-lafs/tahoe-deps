#ifndef __INCL_SHA256MODULE_HPP
#define __INCL_SHA256MODULE_HPP

extern void
init_sha256(PyObject* module);

#endif /* #ifndef __INCL_SHA256MODULE_HPP */
