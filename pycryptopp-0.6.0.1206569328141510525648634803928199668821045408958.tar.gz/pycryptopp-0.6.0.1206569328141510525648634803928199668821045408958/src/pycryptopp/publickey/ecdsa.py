from pycryptopp import _import_my_names

_import_my_names(globals(), "ecdsa_")

del _import_my_names
